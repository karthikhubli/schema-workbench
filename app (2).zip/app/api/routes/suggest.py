import logging

from fastapi import APIRouter, Form, Request
from fastapi.templating import Jinja2Templates

logger = logging.getLogger(__name__)
router = APIRouter()
templates = Jinja2Templates(directory="app/templates")


@router.post("/mappings")
async def suggest_mappings(
    request: Request,
    source_schema_id: str = Form(...),
    target_schema_id: str = Form(...),
):
    payload = {
        "source_schema_id": source_schema_id,
        "target_schema_id": target_schema_id,
    }

    logger.info("Generating mapping suggestions: %s", payload)

    # Placeholder for LLM/embedding-backed suggestions.
    suggestions = [
        {"source": "PV", "target": "MEAS", "confidence": "high"},
        {"source": "SP", "target": "SETPT", "confidence": "high"},
        {"source": "CV", "target": "OUT", "confidence": "medium"},
        {"source": "GAIN", "target": "KP", "confidence": "high"},
        {"source": "RESET", "target": "TI", "confidence": "medium"},
    ]

    return templates.TemplateResponse(
        "partials/mapping_suggestions.html",
        {"request": request, "suggestions": suggestions},
    )
