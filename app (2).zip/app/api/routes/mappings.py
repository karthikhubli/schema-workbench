from fastapi import APIRouter, Form, Request, HTTPException
from fastapi.templating import Jinja2Templates

from app.services.schema_service import get_schema_by_id
from app.services.schema_compatibility_service import calculate_schema_compatibility

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")


@router.post("/compatibility")
async def check_schema_compatibility(
    request: Request,
    source_schema_id: int = Form(...),
    target_schema_id: int = Form(...),
):
    source_schema = get_schema_by_id(source_schema_id)
    target_schema = get_schema_by_id(target_schema_id)

    if source_schema is None:
        return f"""
        <div class="error">
            Source schema not found for ID: {source_schema_id}
        </div>
        """

    if target_schema is None:
        return f"""
        <div class="error">
            Target schema not found for ID: {target_schema_id}
        </div>
        """

    compatibility = calculate_schema_compatibility(
        source_schema,
        target_schema,
    )

    return templates.TemplateResponse(
        "partials/schema_compatibility.html",
        {
            "request": request,
            "compatibility": compatibility,
            "source_schema": source_schema,
            "target_schema": target_schema,
        },
    )