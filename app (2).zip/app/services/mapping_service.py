import logging
from app.repositories import mapping_repository

logger = logging.getLogger(__name__)


def save_mapping_from_form(
    *,
    source_schema_id: int,
    target_schema_id: int,
    notes: str,
) -> int:
    # For the prototype, mapping_items can be filled later from accepted suggestions.
    mapping_id = mapping_repository.create_mapping(
        source_schema_id=source_schema_id,
        target_schema_id=target_schema_id,
        mapping_items=[],
        notes=notes,
        status="Draft",
    )
    logger.info("Saved mapping id=%s", mapping_id)
    return mapping_id
