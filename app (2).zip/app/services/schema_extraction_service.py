import logging
from app.models.schema_models import BlockSchema
from app.services.ollama_service import call_ollama_json

logger = logging.getLogger(__name__)


def extract_schema_from_text(
    vendor: str,
    block_type: str,
    version: str,
    snippet: str,
) -> BlockSchema:
    prompt = f"""
Extract a function block schema from the text below.

Return ONLY valid JSON.

Use this exact JSON structure:

{{
  "vendor": "string",
  "block_type": "string",
  "version": "string",
  "description": "string",
  "pins": [
    {{
      "name": "string",
      "dir": "in",
      "type": "string",
      "mandatory": true,
      "description": "string"
    }}
  ],
  "parameters": [
    {{
      "name": "string",
      "type": "string",
      "default": "string",
      "mandatory": true,
      "description": "string"
    }}
  ],
  "notes": "string"
}}

Rules:
- If vendor is missing, use "{vendor}".
- If block_type is missing, use "{block_type}".
- If version is missing, use "{version}".
- dir must be either "in" or "out".
- mandatory must be true or false.
- Do not include markdown.
- Do not include explanation text.

Text:
{snippet}
"""

    logger.info("Extracting schema from text")

    parsed_json = call_ollama_json(prompt)

    parsed_json["vendor"] = parsed_json.get("vendor") or vendor
    parsed_json["block_type"] = parsed_json.get("block_type") or block_type
    parsed_json["version"] = parsed_json.get("version") or version

    return BlockSchema(**parsed_json)