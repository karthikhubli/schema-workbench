import json
import logging

from fastapi import APIRouter, Request
from fastapi.templating import Jinja2Templates

from app.services.schema_service import get_schema_by_id, list_schemas, get_all_schemas

logger = logging.getLogger(__name__)

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

SAMPLE_SCHEMAS = [
    {"id": 1, "vendor": "Foxboro", "block_type": "PID", "version": "1.0", "status": "Sample"},
    {"id": 2, "vendor": "Honeywell", "block_type": "PID", "version": "1.0", "status": "Sample"},
]


def _schema_options() -> list[dict]:
    schemas = list_schemas()
    return schemas if schemas else SAMPLE_SCHEMAS


def _pretty_json(value) -> str:
    if isinstance(value, str):
        try:
            return json.dumps(json.loads(value or "[]"), indent=2)
        except json.JSONDecodeError:
            return value
    return json.dumps(value or [], indent=2)


@router.get("/")
async def home(request: Request):
    schemas = get_all_schemas()

    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "schemas": schemas,
        },
    )


@router.get("/schemas/new")
async def new_schema(request: Request):
    logger.info("Loading create schema page")
    return templates.TemplateResponse(
        "schema_form.html",
        {"request": request},
    )


@router.get("/schemas/{schema_id}/edit")
async def edit_schema(request: Request, schema_id: int):
    logger.info("Loading edit schema page for id=%s", schema_id)

    schema = get_schema_by_id(schema_id)
    if schema:
        schema["pins_json"] = _pretty_json(schema.get("pins_json"))
        schema["parameters_json"] = _pretty_json(schema.get("parameters_json"))

    return templates.TemplateResponse(
        "schema_edit.html",
        {"request": request, "schema": schema},
    )


@router.get("/mappings")
async def mappings_page(request: Request):
    schemas = get_all_schemas()

    return templates.TemplateResponse(
        "mappings.html",
        {
            "request": request,
            "schemas": schemas,
        },
    )
