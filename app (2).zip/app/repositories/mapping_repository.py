import json
from typing import Any, Optional

from app.db.session import get_connection


def create_mapping(
    *,
    source_schema_id: int,
    target_schema_id: int,
    mapping_items: list[dict[str, Any]],
    notes: Optional[str],
    status: str = "Draft",
) -> int:
    with get_connection() as conn:
        cursor = conn.execute(
            """
            INSERT INTO mappings (
                source_schema_id,
                target_schema_id,
                mapping_json,
                notes,
                status
            )
            VALUES (?, ?, ?, ?, ?)
            """,
            (
                source_schema_id,
                target_schema_id,
                json.dumps(mapping_items),
                notes,
                status,
            ),
        )
        conn.commit()
        return int(cursor.lastrowid)
